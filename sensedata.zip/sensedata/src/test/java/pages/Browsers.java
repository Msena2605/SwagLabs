package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Browsers {

	protected static WebDriver driver;

	public void abrirNavegador(String site) {
		try {
			System.setProperty("webdriver.edge.driver", "./Drivers/msedgedriver.exe");
			driver = new EdgeDriver();
			driver.get(site);
			driver.manage().window().maximize();
		} catch (Exception e) {
			System.out.println("-------- erro ao abrir navegador -------- " + e.getMessage());
			System.out.println("-------- causa do erro -------- " + e.getCause());

		}

	}
}
