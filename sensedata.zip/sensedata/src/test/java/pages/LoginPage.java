package pages;

import org.openqa.selenium.By;

public class LoginPage {

	Metodos metodos = new Metodos();

	public By username = By.id("user-name");
	public By password = By.id("password");
	public By loginbutton = By.id("login-button");

}
