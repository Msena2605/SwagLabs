package steps;

import elementos.ElementosWeb;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.Browsers;
import pages.LoginPage;
import pages.Metodos;


public class TestSenseData {
	
	Browsers browser = new Browsers();
	Metodos metodos = new Metodos();
	LoginPage login = new LoginPage();
	ElementosWeb el = new ElementosWeb();
	
	@Given("que o usuario acessa o site {string}")
	public void que_o_usuario_acessa_o_site(String site) {
		browser.abrirNavegador(site);
	}
	
	@Given("efetue o login")
	public void efetue_o_login() {
	   
		metodos.escrever(login.username, "standard_user");
		metodos.escrever(login.password, "secret_sauce");
		metodos.clicar(login.loginbutton);
	}

	@Given("Organiza os produtos pelo valor")
	public void organiza_os_produtos_pelo_valor() {
	    metodos.clicar(el.organize);
	}

	@When("clicar no produto desejado")
	public void clicar_no_produto_desejado() {
       metodos.clicar(el.produto);
       metodos.clicar(el.carrinho);
	}

	@Then("efetue compra do produto com sucesso")
	public void efetue_compra_do_produto_com_sucesso() {
		metodos.clicar(el.checkout);
		metodos.escrever(el.firstname, "Matheus");
		metodos.escrever(el.lastname, "Sena");
		metodos.escrever(el.postalcode, "28905000");
		metodos.clicar(el.confirmar);
		metodos.clicar(el.finish);
		metodos.clicar(el.backtoproducts);
		
	}
}
